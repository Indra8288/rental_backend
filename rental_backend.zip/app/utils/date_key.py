from datetime import date

def to_date_key(d: date) -> str:
    return f"{d.year:04d}-{d.month:02d}"
