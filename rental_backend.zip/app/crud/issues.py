from sqlalchemy.orm import Session
from fastapi import HTTPException
from datetime import datetime
from app.models.issue_ticket import IssueTicket

def create_issue(db: Session, issue: IssueTicket) -> IssueTicket:
    db.add(issue)
    db.commit()
    db.refresh(issue)
    return issue

def list_issues(db: Session, *, room_no: str | None = None, user_id: int | None = None) -> list[IssueTicket]:
    q = db.query(IssueTicket)
    if room_no:
        q = q.filter(IssueTicket.room_no == room_no)
    if user_id:
        q = q.filter(IssueTicket.created_by_user_id == user_id)
    return q.order_by(IssueTicket.created_at.desc()).all()

def update_issue_status(db: Session, ticket_id: int, status: str) -> IssueTicket:
    t = db.get(IssueTicket, ticket_id)
    if not t:
        raise HTTPException(status_code=404, detail="Ticket not found")
    t.status = status
    t.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(t)
    return t
