from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.api.deps import get_current_user, require_roles
from app.models.enums import Role
from app.schemas.issues import IssueCreate, IssueOut, IssueUpdate
from app.models.issue_ticket import IssueTicket
from app.crud.issues import create_issue, list_issues, update_issue_status

router = APIRouter(prefix="/issues")

@router.post("", response_model=IssueOut)
def create(payload: IssueCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    # client can only create for their room
    if user.role == Role.client.value:
        if not user.room_no:
            raise HTTPException(status_code=400, detail="Client user has no room_no bound")
        room_no = user.room_no
    else:
        # owner/admin must provide room via query param in a different endpoint; keep simple
        raise HTTPException(status_code=403, detail="Only client creates issues in this endpoint")
    ticket = IssueTicket(room_no=room_no, created_by_user_id=user.id, issue_type=payload.issue_type.value, details=payload.details)
    return create_issue(db, ticket)

@router.get("", response_model=list[IssueOut])
def mine(db: Session = Depends(get_db), user=Depends(get_current_user)):
    if user.role == Role.client.value:
        return list_issues(db, user_id=user.id)
    return list_issues(db)

@router.patch("/{ticket_id}", response_model=IssueOut)
def update(ticket_id: int, payload: IssueUpdate, db: Session = Depends(get_db), _=Depends(require_roles(Role.owner, Role.admin))):
    if not payload.status:
        raise HTTPException(status_code=400, detail="status is required")
    return update_issue_status(db, ticket_id, payload.status.value)
