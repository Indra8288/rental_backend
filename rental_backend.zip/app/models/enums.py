import enum

class Role(str, enum.Enum):
    owner = "owner"
    admin = "admin"
    client = "client"

class CustomerStatus(str, enum.Enum):
    active = "Active"
    inactive = "Inactive"

class RoomStatus(str, enum.Enum):
    empty = "EMPTY"
    occupied = "OCCUPIED"
    stopped = "STOPPED"

class PaymentType(str, enum.Enum):
    full = "FULL"
    partial = "PARTIAL"

class PaymentStatus(str, enum.Enum):
    pending = "PENDING"
    accepted = "ACCEPTED"

class IssueType(str, enum.Enum):
    electricity = "Electricity"
    water = "Water"
    door = "Door"
    other = "Other"

class IssueStatus(str, enum.Enum):
    open = "OPEN"
    in_progress = "IN_PROGRESS"
    closed = "CLOSED"
