from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from datetime import date
from app.db.session import get_db
from app.api.deps import require_roles
from app.models.enums import Role
from app.models.room import Room
from app.crud.rooms import list_rooms
from app.crud.payments import ensure_payment_row
from app.utils.date_key import to_date_key

router = APIRouter(prefix="/eom")

@router.get("/rooms")
def list_rooms_for_new_month(date_key: str, db: Session = Depends(get_db), _=Depends(require_roles(Role.owner, Role.admin))):
    # Returns rooms with an ensured payment row for that month (new month input screen)
    rooms = list_rooms(db)
    out = []
    for r in rooms:
        rp = ensure_payment_row(db, r, date_key)
        out.append({"room_no": r.room_no, "remaining": rp.remaining, "status": rp.status})
    return out

@router.post("/start")
def start_eom(new_date_key: str, db: Session = Depends(get_db), _=Depends(require_roles(Role.owner))):
    # Minimal roll-over:
    # - ensure payment row exists for each room for new month
    # - set last_bom on room
    rooms = list_rooms(db)
    today = date.today()
    for r in rooms:
        ensure_payment_row(db, r, new_date_key)
        r.last_bom = today
    db.commit()
    return {"ok": True, "new_date_key": new_date_key, "rooms": len(rooms)}
