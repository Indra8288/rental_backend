from datetime import date
from pydantic import BaseModel, Field
from app.schemas.common import APIModel

class RoomCreate(BaseModel):
    room_no: str = Field(min_length=1, max_length=20)
    price: float

class RoomOut(APIModel):
    room_no: str
    price: float
    status: str
    debt: float
    last_bom: date | None = None

class RoomStatusCard(BaseModel):
    room_no: str
    color: str  # green/blue/white/red
    status_text: str
    debt: float
    remaining: float
