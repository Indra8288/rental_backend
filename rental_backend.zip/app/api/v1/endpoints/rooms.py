from fastapi import APIRouter, Depends, Response
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import date
from app.db.session import get_db
from app.api.deps import require_roles, get_current_user
from app.models.enums import Role, PaymentStatus
from app.schemas.room import RoomOut, RoomStatusCard
from app.crud.rooms import list_rooms, list_empty_rooms, get_room
from app.crud.payments import get_payment
from app.utils.qrcode_utils import make_qr_png_bytes
from app.utils.date_key import to_date_key

router = APIRouter(prefix="/rooms")

@router.get("", response_model=list[RoomOut])
def all_rooms(db: Session = Depends(get_db), _=Depends(require_roles(Role.owner, Role.admin))):
    return list_rooms(db)

@router.get("/empty", response_model=list[RoomOut])
def empty_rooms(db: Session = Depends(get_db), _=Depends(require_roles(Role.owner, Role.admin))):
    return list_empty_rooms(db)

@router.get("/status-cards", response_model=list[RoomStatusCard])
def room_status_cards(date_key: str | None = None, db: Session = Depends(get_db), _=Depends(require_roles(Role.owner, Role.admin))):
    # Colors:
    # Green = already paid (accepted + remaining==0)
    # Blue = pending accept
    # White = new month (no payment row yet)
    # Red = debt (remaining>0 and accepted OR room.debt>0)
    if date_key is None:
        date_key = to_date_key(date.today())

    cards: list[RoomStatusCard] = []
    for r in list_rooms(db):
        rp = get_payment(db, r.room_no, date_key)
        if rp is None:
            cards.append(RoomStatusCard(room_no=r.room_no, color="white", status_text="New month", debt=r.debt, remaining=r.price + r.debt))
            continue
        if rp.status == PaymentStatus.pending.value:
            cards.append(RoomStatusCard(room_no=r.room_no, color="blue", status_text="Pending accept", debt=r.debt, remaining=rp.remaining))
            continue
        if rp.remaining == 0:
            cards.append(RoomStatusCard(room_no=r.room_no, color="green", status_text="Paid", debt=0.0, remaining=0.0))
            continue
        cards.append(RoomStatusCard(room_no=r.room_no, color="red", status_text="Debt", debt=r.debt, remaining=rp.remaining))
    return cards

@router.get("/{room_no}/qr")
def room_qr(room_no: str, db: Session = Depends(get_db), _=Depends(require_roles(Role.owner, Role.admin))):
    # Put any deep-link you want here. For now, encode room_no only.
    _ = get_room(db, room_no)
    png = make_qr_png_bytes(f"room:{room_no}")
    return Response(content=png, media_type="image/png")
